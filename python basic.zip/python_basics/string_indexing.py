# Python 字串索引原來這麼簡單

credit_number = "1234-5678-9876-5432"

first_char = credit_number[0]
print("第一個字元：", first_char)

second_char = credit_number[1]
print("第二個字元：", second_char)

first_four = credit_number[0:4]
print("前四個字元：", first_four)

last_one = credit_number[-1]
print("最後一個字元：", last_one)

last_two = credit_number[-2]
print("最後第 2 個字元：", last_two)