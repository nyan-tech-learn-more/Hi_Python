# Python 寫入檔案
str = r'C:\Users\Luka23\OneDrive\桌面\workspace\TEST.txt'

# text = "嗨!\n祝你一切順利!"
# write
with open(str, 'w') as file:
    file.write('\n go go go')