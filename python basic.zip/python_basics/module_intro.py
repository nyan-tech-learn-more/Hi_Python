import my_module as m

print(m.pi)
print(m.area(3))





# Python 中的模組 Module
# import math as m
# from math import pi
# print(pi)
# help(math)

# print(m.pi)
# print(m.pow(3,2))
# print(m.pow(3,3))

# ceil
# floor
# round

# num = 20.6
# print(m.ceil(num))
# print(m.floor(num))
# print(round(num))