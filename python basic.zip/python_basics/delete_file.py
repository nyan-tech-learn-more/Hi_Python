import os
import shutil
path = r"C:\Users\Luka23\OneDrive\桌面\workspace"
# 刪除檔案
# os.remove(f"{path}/test.txt")

# 刪除空資料夾
# os.rmdir(f"{path}/dirc")

# 刪除資料夾及其內容
# shutil.rmtree()

# 丟到資源回收桶
import send2trash
send2trash.send2trash(fr"{path}\test.txt")
