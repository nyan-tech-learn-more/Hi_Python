# 使用 Python 進行檔案偵測

import os


str = r"C:\Users\Luka23\OneDrive\桌面\workspace\test.txt"
print(str)
if os.path.isfile(str):
    print("該路徑為檔案!")
elif os.path.isdir(str):
    print("該路徑為目錄!")
else:
    print('other')
