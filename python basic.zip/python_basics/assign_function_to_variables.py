# Python 將函式指派給變數

# def hello():
#     print("hello")
#
# hi = hello
# print(hello)
# print(hi)

say = print
say("hello")
say("hi")