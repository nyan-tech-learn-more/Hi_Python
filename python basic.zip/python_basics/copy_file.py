# 使用 PYTHON 複製檔案

import shutil
# - copyfile
# - copy
# - copy2
w = r"C:\Users\Luka23\OneDrive\桌面\workspace"
source = f"{w}/source_file.txt"
destination = f"{w}/destination_file.txt"
shutil.copyfile(source, destination)