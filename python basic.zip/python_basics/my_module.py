pi = 3.14

def square(x):
    return x ** 2

def cube(x):
    return x ** 3

def area(radius):
    return pi * radius ** 2
