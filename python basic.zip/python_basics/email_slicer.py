# Email 字串分析

email = "codeshiba@gmail.com"
index = email.index("@")
print(index)
print(email[:index])
print(email[(index+1):])