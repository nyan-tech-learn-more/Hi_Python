str = r"C:\Users\Luka23\OneDrive\桌面\workspace\test.txt"
try:
    with open(str) as file:
        print(file.read())
except FileNotFoundError:
    print("檔案並不存在")