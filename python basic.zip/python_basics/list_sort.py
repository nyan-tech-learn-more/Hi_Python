# Python 中的 Sort 方法

# sort

# list

# num_list = [1, 3, 5, 2, 4]
# print(num_list)
# num_list.sort()
# print(num_list)
# num_list.sort(reverse=True)
# print(num_list)

# str_list = ['Jack', 'Lin', 'Tom', 'Andy', "Z"]
# print(str_list)
# str_list.sort()
# print(str_list)
# str_list.sort(reverse=True)
# print(str_list)

# 元組的排列 Tuple

students = [
    ("小明", 170, "C"),
    ("小華", 150, "B"),
    ("老王", 160, "A")
]

sorted_students = sorted(students, key=lambda student: student[2])
print(sorted_students)







