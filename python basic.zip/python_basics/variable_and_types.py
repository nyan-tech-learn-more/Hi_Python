# integer 整數
age = 30

# float 浮點數
gpa = 3.3
print(f"我的 GPA {gpa} 分")
print(type(gpa))
# string
name = 'Peter'
print(f"我的名字是 {name} ")
print(type(name))
# boolean # true, false

is_online = True
print(f"在線上嗎？{is_online}")
print(type(is_online))

