# Python 中的方法重寫(Method Overriding)

class Animal:
    def eat(self):
        print("動物正在吃東西")

# 哺乳類 Mammal
class Mammal(Animal):
    def hi(self):
        print("我是哺乳類")
    pass
# 貓 Cat
class Cat(Mammal):
    def eat(self):
        print("小貓正在吃魚")

# 狗 Dog
class Dog(Mammal):
    def eat(self):
        print("小狗正在啃骨頭")

# cat = Cat()
# cat.eat()
# dog = Dog()
# dog.eat()
m = Mammal()
m.eat()

# class Rabbit(Animal):
#     def eat(self):
#         print("兔子在吃紅蘿蔔")
#
# animal = Animal()
# animal.eat()
# rabbit = Rabbit()
# rabbit.eat()