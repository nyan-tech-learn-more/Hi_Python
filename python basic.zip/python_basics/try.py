import math
x = 9.5
print(math.ceil(x))
print(math.floor(x))