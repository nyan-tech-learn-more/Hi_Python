# OOP - Python 中的繼承

# 父類別 <-> 子類別

# 動物
class Animal:
    aLive = True

    def eat(self):
        print("這個動物正在吃東西")
    def sleep(self):
        print("這個動物正在睡覺")
# 兔子
class Rabbit(Animal):
    def jump(self):
        print("這隻兔子正在跳")
# animal = Animal()
# animal.eat()
# animal.sleep()
# rabbit = Rabbit()
# rabbit.jump()
# rabbit.eat()

# 魚
class Fish(Animal):
    def swim(self):
        print("魚正在游泳")

# 老鷹
class Hawk(Animal):
    def fly(self):
        print("老鷹正在飛")

fish = Fish()

hawk = Hawk()
hawk.fly()