# Python 中的 while 迴圈

# 範例 1
# name = ""
# while name == "":
#     name = input("請輸入你的名字：")
# print(f"你好, {name}！")

# 範例 2
# food = input("請輸入你喜歡吃的食物：")
# while food != "q":
#     print(f"你喜歡的食物是{food}")
#     food = input("請輸入你喜歡吃的食物：")
# print("再見！")

# 範例 3
num = int(input("請輸入 1 到 10 之間的數字："))
while num < 1 or num > 10:
    print(f"你輸入的數字 {num} 是無效的")
    num = int(input("請輸入 1 到 10 之間的數字："))
print(f"你輸入了 {num}")