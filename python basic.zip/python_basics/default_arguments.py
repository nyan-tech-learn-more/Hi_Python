# 函式的預設引數 (default arguments)

def greet(name, greeting="Hello"):
    print(f"{greeting}, {name}")

# greet("CodeShiba")
# greet("John")
