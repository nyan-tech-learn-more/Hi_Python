import requests
from bs4 import BeautifulSoup

url = 'https://lukahuang.github.io/simple_pages/amazon_jp.html'
response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")

product_name = soup.find('span', id="productTitle").getText()
price_text = soup.find('span', id="priceblock_ourprice").getText()

print('product_name: ', product_name.strip())
print('price_text:', price_text)
