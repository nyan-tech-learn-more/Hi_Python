import re
pattern = r'[\d,]+'
text = "¥5,032,970"
result = re.search(pattern, text)
print(result)

if result:
  print("Search successful.")
else:
  print("Search unsuccessful.")