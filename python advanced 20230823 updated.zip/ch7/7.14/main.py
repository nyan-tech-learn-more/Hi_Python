import requests
def get_popular_movies():
    url = "https://imdb8.p.rapidapi.com/title/get-most-popular-movies"
    querystring = {"homeCountry":"US","purchaseCountry":"US","currentCountry":"US"}
    headers = {
        'x-rapidapi-host': "imdb8.p.rapidapi.com",
        'x-rapidapi-key': "YOUR-RAPIDAPI-KEY"
        }
    response = requests.request("GET", url, headers=headers, params=querystring)
    return response.json()

def get_videos(title_id):
    url = "https://imdb8.p.rapidapi.com/title/get-videos"
    querystring = {"tconst": title_id, "limit":"25","region":"US"}
    headers = {
        'x-rapidapi-host': "imdb8.p.rapidapi.com",
        'x-rapidapi-key': "YOUR-RAPIDAPI-KEY"
        }
    response = requests.request("GET", url, headers=headers, params=querystring)
    print(response.json()['resource']['title'])

title_list = get_popular_movies()
for title_id in title_list:
    # slice
    get_videos(title_id[7:-1])
# get_videos('tt0944947')