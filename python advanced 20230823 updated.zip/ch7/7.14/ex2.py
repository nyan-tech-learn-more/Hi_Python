# https://rapidapi.com/apidojo/api/imdb8/
import requests

url = "https://imdb8.p.rapidapi.com/title/get-videos"

querystring = {"tconst":"tt0944947","limit":"25","region":"US"}

headers = {
    'x-rapidapi-host': "imdb8.p.rapidapi.com",
    'x-rapidapi-key': "YOUR-RAPIDAPI-KEY"
    }

response = requests.request("GET", url, headers=headers, params=querystring)

print(response.text)
