import requests

url = "https://imdb8.p.rapidapi.com/title/get-most-popular-movies"

querystring = {"homeCountry":"US","purchaseCountry":"US","currentCountry":"US"}

headers = {
    'x-rapidapi-host': "imdb8.p.rapidapi.com",
    'x-rapidapi-key': "YOUR-RAPIDAPI-KEY"
    }

response = requests.request("GET", url, headers=headers, params=querystring)

print(response.text)