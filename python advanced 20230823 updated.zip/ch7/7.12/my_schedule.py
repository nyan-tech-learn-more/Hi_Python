import schedule # scheduler
import time

def job():
	print("I'm working...")


schedule.every(1).seconds.do(job)

# 無窮迴圈

while True:
	schedule.run_pending()
	# 閒置
	time.sleep(1)
