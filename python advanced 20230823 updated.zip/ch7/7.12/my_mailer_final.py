import smtplib
import ssl
import os
from dotenv import load_dotenv
load_dotenv()

def send_email(name, price):
    port = 587  # For starttls
    smtp_server = "smtp.gmail.com"
    sender_email = "codeshiba@gmail.com"
    receiver_email = "codingluka@gmail.com"
    password = os.getenv('EMAIL_PASSWORD')
    print("email is sending")
    message = f"""\
Subject: {name} 降價囉

{name}的價格已經降至{price}.""".encode('utf-8')

    context = ssl.create_default_context()
    with smtplib.SMTP(smtp_server, port) as server:
        server.ehlo()  # Can be omitted
        server.starttls(context=context)
        server.ehlo()  # Can be omitted
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, message)

# send_email('PS5', 19000)
