import requests
import re
from bs4 import BeautifulSoup

def parse_html(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")
    product_name = soup.find('span', id="productTitle").getText()
    price_text = soup.find('span', id="priceblock_ourprice").getText()
    print('product_name: ', product_name.strip())
    print('price_text:', parse_price(price_text))
    return parse_price(price_text)

def parse_price(text):
    pattern = r'[\d,]+'
    result = re.search(pattern, text).group(0)
    return int(result.replace(',', ''))

# url = 'https://www.amazon.co.jp/-/en/dp/B07WXL5YPW/ref=sr_1_6?crid=2U8IZBQ08ZC19&keywords=switch&qid=1644110301&sprefix=swit%2Caps%2C645&sr=8-6&th=1'
# parse_html(url)