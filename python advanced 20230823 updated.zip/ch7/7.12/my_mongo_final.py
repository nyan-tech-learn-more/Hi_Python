from pymongo import MongoClient
import datetime
import os
from dotenv import load_dotenv
load_dotenv()

MONGODB_URL = os.getenv('MONGODB_URL')
DATABASE_NAME = 'codeshiba'
COLLECTION_NAME = "min_price"

def init_mongo():
    client = MongoClient(MONGODB_URL)
    db = client[DATABASE_NAME]
    return db

def get_min_price(name):
    db = init_mongo()
    prices = db.prices
    prices = db.prices.find({"product_name": name})
    if prices[0] and prices[0]['price']:
        return prices[0]['price']

def set_min_price(name, price):
    db = init_mongo()
    # pymongo
    price_dict = {
        "product_name": name,
        "price": price,
        "date": datetime.datetime.utcnow()
    }
    prices = db.prices
    price_list = db.prices.find({"product_name": name})
    if price_list.count() == 0:
        init_product_price(name, price)
    else:
        new_values = {"$set": price_dict}
        my_query = {"product_name": name}
        prices.update_one(my_query, new_values)

def init_product_price(name, price):
    db = init_mongo()
    price_dict = {
        "product_name": name,
        "price": price,
        "date": datetime.datetime.utcnow()
    }
    prices = db.prices
    price_id = prices.insert_one(price_dict).inserted_id
    price_id

# init_product_price("PS5", 20000)
# set_min_price("PS5", 25000)
# price = get_min_price("PS5")
# print(price)