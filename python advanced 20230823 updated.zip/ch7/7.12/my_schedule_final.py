import schedule
import time
from my_crawler_final import parse_html

def job():
	print("I am working")
def parse_shop():
	try:
		parse_html('https://www.amazon.co.jp/-/en/dp/B07WXL5YPW/ref=sr_1_6?crid=2U8IZBQ08ZC19&keywords=switch&qid=1644110301&sprefix=swit%2Caps%2C645&sr=8-6&th=1')
	except Exception:
		pass

schedule.every(1).seconds.do(job)
schedule.every(5).seconds.do(parse_shop)
# 無窮迴圈

while True:
	schedule.run_pending()
	time.sleep(1)
