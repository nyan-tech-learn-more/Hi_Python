from pymongo import MongoClient
import datetime
import os
from dotenv import load_dotenv
load_dotenv()

MONGODB_URL = os.getenv('MONGODB_URL')
DATABASE_NAME = 'codeshiba'
COLLECTION_NAME = "min_price"

def init_mongo():
    client = MongoClient(MONGODB_URL)
    db = client[DATABASE_NAME]
    return db

def get_min_price():
    pass

def set_min_price():
    pass

def insert_test():
    db = init_mongo()
    post = {
        "author": "Luka",
        "text": "My second blog post!",
        "tags": ["mongodb", "python", "pymongo"],
        "date": datetime.datetime.utcnow()
    }
    posts = db.posts
    post_id = posts.insert_one(post).inserted_id
    post_id

insert_test()



