import schedule # scheduler
import time
import my_crawler_final

def job():
	print("I'm working...")
def parse_shop():
	try:
		url = 'https://www.amazon.co.jp/-/en/dp/B07WXL5YPW/ref=sr_1_6?crid=2U8IZBQ08ZC19&keywords=switch&qid=1644110301&sprefix=swit%2Caps%2C645&sr=8-6&th=1'
		my_crawler_final.parse_html(url)
	except Exception as e:
		print('exception!')


schedule.clear()
schedule.every(1).seconds.do(job)
schedule.every(5).seconds.do(parse_shop)

# 無窮迴圈

while True:
	schedule.run_pending()
	# 閒置
	time.sleep(1)
