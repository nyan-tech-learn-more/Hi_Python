import requests
from bs4 import BeautifulSoup

# 安裝
# conda install beautifulsoup4

response = requests.get('https://lukahuang.github.io/simple_pages/page_1.html')
soup = BeautifulSoup(response.text, "html.parser")
print(soup.find("p").getText())
