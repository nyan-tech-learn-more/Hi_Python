import requests
from bs4 import BeautifulSoup

url = 'https://lukahuang.github.io/simple_pages/amazon_jp.html'
response = requests.get(url)
soup = BeautifulSoup(response.text, "html.parser")
# soup.find("a", id="link3")
print("title:")
print(soup.find('span', id="productTitle").getText())
print("price:")
print(soup.find('span', id="priceblock_ourprice").getText())