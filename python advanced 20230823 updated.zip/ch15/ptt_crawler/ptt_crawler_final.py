import requests
import re
from bs4 import BeautifulSoup

MOBILE_SALES_URL = 'https://www.pttweb.cc/bbs/mobilesales'

def get_links():
  response = requests.get(MOBILE_SALES_URL)
  soup = BeautifulSoup(response.text, "html.parser")
  return soup.find('.e7-article-default')

def parse_price(text):
    pattern = r'[\d,]+'
    result = re.search(pattern, text).group(0)
    return int(result.replace(',', ''))

get_links()
print(get_links())

# url = 'https://www.amazon.co.jp/-/en/dp/B07WXL5YPW/ref=sr_1_6?crid=2U8IZBQ08ZC19&keywords=switch&qid=1644110301&sprefix=swit%2Caps%2C645&sr=8-6&th=1'
# parse_html(url)

