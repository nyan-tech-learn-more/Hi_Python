import schedule
import time
from my_mongo_final import get_min_price
from my_mongo_final import set_min_price
from ptt_crawler_final import parse_html
from my_mailer_final import send_email


def job():
	print("I am working")


product_name = "Nintendo Switch 本体"
set_min_price(product_name, 60000)

def parse_shop(min_price=None):
	if not min_price:
		min_price = get_min_price(product_name)
	try:
		price = parse_html('https://www.amazon.co.jp/-/en/dp/B07WXL5YPW/ref=sr_1_6?crid=2U8IZBQ08ZC19&keywords=switch&qid=1644110301&sprefix=swit%2Caps%2C645&sr=8-6&th=1')
		if price < min_price:
			set_min_price(product_name, price)
			min_price = price
			send_email(product_name, price)
	except Exception as e:
		print(e)

schedule.every(1).seconds.do(job)
schedule.every(5).seconds.do(parse_shop)
# 無窮迴圈

while True:
	schedule.run_pending()
	time.sleep(1)


