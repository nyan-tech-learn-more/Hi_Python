def function_1():
    print("Function 1 excuted")

def function_2():
    print("Function 2 excuted")

print("__name__:", __name__)
if __name__ == '__main__':
    function_1()
    function_2()
