def smart_divide(func):
    def inner(a, b):
        if b == 0:
            print("b should not be zero")
            return

        return func(a, b)
    return inner

@smart_divide
def divide(a, b):
    return a/b

print(divide(3,6))
print(divide(12,6))
print(divide(3,0))