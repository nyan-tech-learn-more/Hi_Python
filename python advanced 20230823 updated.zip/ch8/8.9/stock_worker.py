import time
import price_checker
import stock_mongo
def job():
    stocks = stock_mongo.get_stocks()
    for stock in stocks:
        name = stock['name']
        price = stock['price']
        operator = stock['operator']
        print(name, operator, price)
        price_checker.check_price(name, operator, price)
        time.sleep(1)
    pass

job()
# schedule.every(10).seconds.do(job)
# schedule.every(10).minutes.do(job)

#
# while True:
#     schedule.run_pending()
#     time.sleep(1)

